"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Protocol = exports.DEFAULT_REQUEST_TIMEOUT_MSEC = void 0;
exports.mergeCapabilities = mergeCapabilities;
var types_js_1 = require("../types.js");
/**
 * The default request timeout, in miliseconds.
 */
exports.DEFAULT_REQUEST_TIMEOUT_MSEC = 60000;
/**
 * Implements MCP protocol framing on top of a pluggable transport, including
 * features like request/response linking, notifications, and progress.
 */
var Protocol = /** @class */ (function () {
    function Protocol(_options) {
        var _this = this;
        this._options = _options;
        this._requestMessageId = 0;
        this._requestHandlers = new Map();
        this._requestHandlerAbortControllers = new Map();
        this._notificationHandlers = new Map();
        this._responseHandlers = new Map();
        this._progressHandlers = new Map();
        this._timeoutInfo = new Map();
        this.setNotificationHandler(types_js_1.CancelledNotificationSchema, function (notification) {
            var controller = _this._requestHandlerAbortControllers.get(notification.params.requestId);
            controller === null || controller === void 0 ? void 0 : controller.abort(notification.params.reason);
        });
        this.setNotificationHandler(types_js_1.ProgressNotificationSchema, function (notification) {
            _this._onprogress(notification);
        });
        this.setRequestHandler(types_js_1.PingRequestSchema, 
        // Automatic pong by default.
        function (_request) { return ({}); });
    }
    Protocol.prototype._setupTimeout = function (messageId, timeout, maxTotalTimeout, onTimeout, resetTimeoutOnProgress) {
        if (resetTimeoutOnProgress === void 0) { resetTimeoutOnProgress = false; }
        this._timeoutInfo.set(messageId, {
            timeoutId: setTimeout(onTimeout, timeout),
            startTime: Date.now(),
            timeout: timeout,
            maxTotalTimeout: maxTotalTimeout,
            resetTimeoutOnProgress: resetTimeoutOnProgress,
            onTimeout: onTimeout
        });
    };
    Protocol.prototype._resetTimeout = function (messageId) {
        var info = this._timeoutInfo.get(messageId);
        if (!info)
            return false;
        var totalElapsed = Date.now() - info.startTime;
        if (info.maxTotalTimeout && totalElapsed >= info.maxTotalTimeout) {
            this._timeoutInfo.delete(messageId);
            throw new types_js_1.McpError(types_js_1.ErrorCode.RequestTimeout, "Maximum total timeout exceeded", { maxTotalTimeout: info.maxTotalTimeout, totalElapsed: totalElapsed });
        }
        clearTimeout(info.timeoutId);
        info.timeoutId = setTimeout(info.onTimeout, info.timeout);
        return true;
    };
    Protocol.prototype._cleanupTimeout = function (messageId) {
        var info = this._timeoutInfo.get(messageId);
        if (info) {
            clearTimeout(info.timeoutId);
            this._timeoutInfo.delete(messageId);
        }
    };
    /**
     * Attaches to the given transport, starts it, and starts listening for messages.
     *
     * The Protocol object assumes ownership of the Transport, replacing any callbacks that have already been set, and expects that it is the only user of the Transport instance going forward.
     */
    Protocol.prototype.connect = function (transport) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this._transport = transport;
                        this._transport.onclose = function () {
                            _this._onclose();
                        };
                        this._transport.onerror = function (error) {
                            _this._onerror(error);
                        };
                        this._transport.onmessage = function (message, extra) {
                            if ((0, types_js_1.isJSONRPCResponse)(message) || (0, types_js_1.isJSONRPCError)(message)) {
                                _this._onresponse(message);
                            }
                            else if ((0, types_js_1.isJSONRPCRequest)(message)) {
                                _this._onrequest(message, extra);
                            }
                            else if ((0, types_js_1.isJSONRPCNotification)(message)) {
                                _this._onnotification(message);
                            }
                            else {
                                _this._onerror(new Error("Unknown message type: ".concat(JSON.stringify(message))));
                            }
                        };
                        return [4 /*yield*/, this._transport.start()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    Protocol.prototype._onclose = function () {
        var _a;
        var responseHandlers = this._responseHandlers;
        this._responseHandlers = new Map();
        this._progressHandlers.clear();
        this._transport = undefined;
        (_a = this.onclose) === null || _a === void 0 ? void 0 : _a.call(this);
        var error = new types_js_1.McpError(types_js_1.ErrorCode.ConnectionClosed, "Connection closed");
        for (var _i = 0, _b = responseHandlers.values(); _i < _b.length; _i++) {
            var handler = _b[_i];
            handler(error);
        }
    };
    Protocol.prototype._onerror = function (error) {
        var _a;
        (_a = this.onerror) === null || _a === void 0 ? void 0 : _a.call(this, error);
    };
    Protocol.prototype._onnotification = function (notification) {
        var _this = this;
        var _a;
        var handler = (_a = this._notificationHandlers.get(notification.method)) !== null && _a !== void 0 ? _a : this.fallbackNotificationHandler;
        // Ignore notifications not being subscribed to.
        if (handler === undefined) {
            return;
        }
        // Starting with Promise.resolve() puts any synchronous errors into the monad as well.
        Promise.resolve()
            .then(function () { return handler(notification); })
            .catch(function (error) {
            return _this._onerror(new Error("Uncaught error in notification handler: ".concat(error)));
        });
    };
    Protocol.prototype._onrequest = function (request, extra) {
        var _this = this;
        var _a, _b, _c, _d;
        var handler = (_a = this._requestHandlers.get(request.method)) !== null && _a !== void 0 ? _a : this.fallbackRequestHandler;
        if (handler === undefined) {
            (_b = this._transport) === null || _b === void 0 ? void 0 : _b.send({
                jsonrpc: "2.0",
                id: request.id,
                error: {
                    code: types_js_1.ErrorCode.MethodNotFound,
                    message: "Method not found",
                },
            }).catch(function (error) {
                return _this._onerror(new Error("Failed to send an error response: ".concat(error)));
            });
            return;
        }
        var abortController = new AbortController();
        this._requestHandlerAbortControllers.set(request.id, abortController);
        var fullExtra = {
            signal: abortController.signal,
            sessionId: (_c = this._transport) === null || _c === void 0 ? void 0 : _c.sessionId,
            _meta: (_d = request.params) === null || _d === void 0 ? void 0 : _d._meta,
            sendNotification: function (notification) {
                return _this.notification(notification, { relatedRequestId: request.id });
            },
            sendRequest: function (r, resultSchema, options) {
                return _this.request(r, resultSchema, __assign(__assign({}, options), { relatedRequestId: request.id }));
            },
            authInfo: extra === null || extra === void 0 ? void 0 : extra.authInfo,
            requestId: request.id,
        };
        // Starting with Promise.resolve() puts any synchronous errors into the monad as well.
        Promise.resolve()
            .then(function () { return handler(request, fullExtra); })
            .then(function (result) {
            var _a;
            if (abortController.signal.aborted) {
                return;
            }
            return (_a = _this._transport) === null || _a === void 0 ? void 0 : _a.send({
                result: result,
                jsonrpc: "2.0",
                id: request.id,
            });
        }, function (error) {
            var _a, _b;
            if (abortController.signal.aborted) {
                return;
            }
            return (_a = _this._transport) === null || _a === void 0 ? void 0 : _a.send({
                jsonrpc: "2.0",
                id: request.id,
                error: {
                    code: Number.isSafeInteger(error["code"])
                        ? error["code"]
                        : types_js_1.ErrorCode.InternalError,
                    message: (_b = error.message) !== null && _b !== void 0 ? _b : "Internal error",
                },
            });
        })
            .catch(function (error) {
            return _this._onerror(new Error("Failed to send response: ".concat(error)));
        })
            .finally(function () {
            _this._requestHandlerAbortControllers.delete(request.id);
        });
    };
    Protocol.prototype._onprogress = function (notification) {
        var _a = notification.params, progressToken = _a.progressToken, params = __rest(_a, ["progressToken"]);
        var messageId = Number(progressToken);
        var handler = this._progressHandlers.get(messageId);
        if (!handler) {
            this._onerror(new Error("Received a progress notification for an unknown token: ".concat(JSON.stringify(notification))));
            return;
        }
        var responseHandler = this._responseHandlers.get(messageId);
        var timeoutInfo = this._timeoutInfo.get(messageId);
        if (timeoutInfo && responseHandler && timeoutInfo.resetTimeoutOnProgress) {
            try {
                this._resetTimeout(messageId);
            }
            catch (error) {
                responseHandler(error);
                return;
            }
        }
        handler(params);
    };
    Protocol.prototype._onresponse = function (response) {
        var messageId = Number(response.id);
        var handler = this._responseHandlers.get(messageId);
        if (handler === undefined) {
            this._onerror(new Error("Received a response for an unknown message ID: ".concat(JSON.stringify(response))));
            return;
        }
        this._responseHandlers.delete(messageId);
        this._progressHandlers.delete(messageId);
        this._cleanupTimeout(messageId);
        if ((0, types_js_1.isJSONRPCResponse)(response)) {
            handler(response);
        }
        else {
            var error = new types_js_1.McpError(response.error.code, response.error.message, response.error.data);
            handler(error);
        }
    };
    Object.defineProperty(Protocol.prototype, "transport", {
        get: function () {
            return this._transport;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Closes the connection.
     */
    Protocol.prototype.close = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, ((_a = this._transport) === null || _a === void 0 ? void 0 : _a.close())];
                    case 1:
                        _b.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Sends a request and wait for a response.
     *
     * Do not use this method to emit notifications! Use notification() instead.
     */
    Protocol.prototype.request = function (request, resultSchema, options) {
        var _this = this;
        var _a = options !== null && options !== void 0 ? options : {}, relatedRequestId = _a.relatedRequestId, resumptionToken = _a.resumptionToken, onresumptiontoken = _a.onresumptiontoken;
        return new Promise(function (resolve, reject) {
            var _a, _b, _c, _d, _e, _f;
            if (!_this._transport) {
                reject(new Error("Not connected"));
                return;
            }
            if (((_a = _this._options) === null || _a === void 0 ? void 0 : _a.enforceStrictCapabilities) === true) {
                _this.assertCapabilityForMethod(request.method);
            }
            (_b = options === null || options === void 0 ? void 0 : options.signal) === null || _b === void 0 ? void 0 : _b.throwIfAborted();
            var messageId = _this._requestMessageId++;
            var jsonrpcRequest = __assign(__assign({}, request), { jsonrpc: "2.0", id: messageId });
            if (options === null || options === void 0 ? void 0 : options.onprogress) {
                _this._progressHandlers.set(messageId, options.onprogress);
                jsonrpcRequest.params = __assign(__assign({}, request.params), { _meta: __assign(__assign({}, (((_c = request.params) === null || _c === void 0 ? void 0 : _c._meta) || {})), { progressToken: messageId }) });
            }
            var cancel = function (reason) {
                var _a;
                _this._responseHandlers.delete(messageId);
                _this._progressHandlers.delete(messageId);
                _this._cleanupTimeout(messageId);
                (_a = _this._transport) === null || _a === void 0 ? void 0 : _a.send({
                    jsonrpc: "2.0",
                    method: "notifications/cancelled",
                    params: {
                        requestId: messageId,
                        reason: String(reason),
                    },
                }, { relatedRequestId: relatedRequestId, resumptionToken: resumptionToken, onresumptiontoken: onresumptiontoken }).catch(function (error) {
                    return _this._onerror(new Error("Failed to send cancellation: ".concat(error)));
                });
                reject(reason);
            };
            _this._responseHandlers.set(messageId, function (response) {
                var _a;
                if ((_a = options === null || options === void 0 ? void 0 : options.signal) === null || _a === void 0 ? void 0 : _a.aborted) {
                    return;
                }
                if (response instanceof Error) {
                    return reject(response);
                }
                try {
                    var result = resultSchema.parse(response.result);
                    resolve(result);
                }
                catch (error) {
                    reject(error);
                }
            });
            (_d = options === null || options === void 0 ? void 0 : options.signal) === null || _d === void 0 ? void 0 : _d.addEventListener("abort", function () {
                var _a;
                cancel((_a = options === null || options === void 0 ? void 0 : options.signal) === null || _a === void 0 ? void 0 : _a.reason);
            });
            var timeout = (_e = options === null || options === void 0 ? void 0 : options.timeout) !== null && _e !== void 0 ? _e : exports.DEFAULT_REQUEST_TIMEOUT_MSEC;
            var timeoutHandler = function () { return cancel(new types_js_1.McpError(types_js_1.ErrorCode.RequestTimeout, "Request timed out", { timeout: timeout })); };
            _this._setupTimeout(messageId, timeout, options === null || options === void 0 ? void 0 : options.maxTotalTimeout, timeoutHandler, (_f = options === null || options === void 0 ? void 0 : options.resetTimeoutOnProgress) !== null && _f !== void 0 ? _f : false);
            _this._transport.send(jsonrpcRequest, { relatedRequestId: relatedRequestId, resumptionToken: resumptionToken, onresumptiontoken: onresumptiontoken }).catch(function (error) {
                _this._cleanupTimeout(messageId);
                reject(error);
            });
        });
    };
    /**
     * Emits a notification, which is a one-way message that does not expect a response.
     */
    Protocol.prototype.notification = function (notification, options) {
        return __awaiter(this, void 0, void 0, function () {
            var jsonrpcNotification;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this._transport) {
                            throw new Error("Not connected");
                        }
                        this.assertNotificationCapability(notification.method);
                        jsonrpcNotification = __assign(__assign({}, notification), { jsonrpc: "2.0" });
                        return [4 /*yield*/, this._transport.send(jsonrpcNotification, options)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Registers a handler to invoke when this protocol object receives a request with the given method.
     *
     * Note that this will replace any previous request handler for the same method.
     */
    Protocol.prototype.setRequestHandler = function (requestSchema, handler) {
        var method = requestSchema.shape.method.value;
        this.assertRequestHandlerCapability(method);
        this._requestHandlers.set(method, function (request, extra) {
            return Promise.resolve(handler(requestSchema.parse(request), extra));
        });
    };
    /**
     * Removes the request handler for the given method.
     */
    Protocol.prototype.removeRequestHandler = function (method) {
        this._requestHandlers.delete(method);
    };
    /**
     * Asserts that a request handler has not already been set for the given method, in preparation for a new one being automatically installed.
     */
    Protocol.prototype.assertCanSetRequestHandler = function (method) {
        if (this._requestHandlers.has(method)) {
            throw new Error("A request handler for ".concat(method, " already exists, which would be overridden"));
        }
    };
    /**
     * Registers a handler to invoke when this protocol object receives a notification with the given method.
     *
     * Note that this will replace any previous notification handler for the same method.
     */
    Protocol.prototype.setNotificationHandler = function (notificationSchema, handler) {
        this._notificationHandlers.set(notificationSchema.shape.method.value, function (notification) {
            return Promise.resolve(handler(notificationSchema.parse(notification)));
        });
    };
    /**
     * Removes the notification handler for the given method.
     */
    Protocol.prototype.removeNotificationHandler = function (method) {
        this._notificationHandlers.delete(method);
    };
    return Protocol;
}());
exports.Protocol = Protocol;
function mergeCapabilities(base, additional) {
    return Object.entries(additional).reduce(function (acc, _a) {
        var key = _a[0], value = _a[1];
        if (value && typeof value === "object") {
            acc[key] = acc[key] ? __assign(__assign({}, acc[key]), value) : value;
        }
        else {
            acc[key] = value;
        }
        return acc;
    }, __assign({}, base));
}
